export {
  reactiveAdd as add
} from '../../subscribe-function/from/many/reactive-function/built-in/arithmetic/reactive-add';
export {
  reactiveSubtract as sub
} from '../../subscribe-function/from/many/reactive-function/built-in/arithmetic/reactive-subtract';
export {
  reactiveMultiply as mul
} from '../../subscribe-function/from/many/reactive-function/built-in/arithmetic/reactive-multiply';
export {
  reactiveDivide as div
} from '../../subscribe-function/from/many/reactive-function/built-in/arithmetic/reactive-divide';


export {
  reactiveAdd as addSF
} from '../../subscribe-function/from/many/reactive-function/built-in/arithmetic/reactive-add';
export {
  reactiveSubtract as subSF
} from '../../subscribe-function/from/many/reactive-function/built-in/arithmetic/reactive-subtract';
export {
  reactiveMultiply as mulSF
} from '../../subscribe-function/from/many/reactive-function/built-in/arithmetic/reactive-multiply';
export {
  reactiveDivide as divSF
} from '../../subscribe-function/from/many/reactive-function/built-in/arithmetic/reactive-divide';


export {
  reactiveAdd as add$$
} from '../../subscribe-function/from/many/reactive-function/built-in/arithmetic/reactive-add';
export {
  reactiveSubtract as sub$$
} from '../../subscribe-function/from/many/reactive-function/built-in/arithmetic/reactive-subtract';
export {
  reactiveMultiply as mul$$
} from '../../subscribe-function/from/many/reactive-function/built-in/arithmetic/reactive-multiply';
export {
  reactiveDivide as div$$
} from '../../subscribe-function/from/many/reactive-function/built-in/arithmetic/reactive-divide';

