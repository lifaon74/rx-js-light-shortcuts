export {
  reactiveEqual as eq
} from '../../subscribe-function/from/many/reactive-function/built-in/comparison/reactive-equal';
export {
  reactiveNotEqual as neq
} from '../../subscribe-function/from/many/reactive-function/built-in/comparison/reactive-not-equal';
export {
  reactiveGreaterThan as gt
} from '../../subscribe-function/from/many/reactive-function/built-in/comparison/reactive-greater-than';
export {
  reactiveGreaterThanOrEqual as gte
} from '../../subscribe-function/from/many/reactive-function/built-in/comparison/reactive-greater-than-or-equal';
export {
  reactiveLowerThan as lt
} from '../../subscribe-function/from/many/reactive-function/built-in/comparison/reactive-lower-than';
export {
  reactiveLowerThanOrEqual as lte
} from '../../subscribe-function/from/many/reactive-function/built-in/comparison/reactive-lower-than-or-equal';


